package my_cp;

class test2
{
  int some_field;

  test2()
  {
    some_field=1;
  }
};
