class test
{
  public static void main(String[] args)
  {
    test2 my_test2=new test2();
    assert my_test2.some_field == 1 : "checking some_field";
  }
}
