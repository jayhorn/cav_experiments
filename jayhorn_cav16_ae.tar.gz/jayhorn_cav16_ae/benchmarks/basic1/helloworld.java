// from
// http://www.thegeekstuff.com/2010/02/java-hello-world-example-how-to-write-and-execute-java-program-on-unix-os/

/* Hello World Java Program */
class helloworld  {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

