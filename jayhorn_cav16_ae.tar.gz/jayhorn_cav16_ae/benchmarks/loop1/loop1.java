class loop1
{
  public static void main(String[] args)
  {
    for(int i=0; i<100; i++)
    {
      int j=i;
    }
  }
}

