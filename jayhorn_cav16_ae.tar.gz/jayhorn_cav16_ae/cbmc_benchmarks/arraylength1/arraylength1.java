class arraylength1
{
  public static void main(String[] args)
  {
    int size=10;
    int int_array[]=new int[size];

    assert int_array.length == 10;
  }
}

