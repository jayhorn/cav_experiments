class store_load1
{
  public static void main(String[] args)
  {
    if (true) {
      int a0 = 0;
      int a1 = 1;
      int a2 = 2;
      int a3 = 3;
      int a4 = 4;
      assert 0 == a0;
      assert 1 == a1;
      assert 2 == a2;
      assert 3 == a3;
      assert 4 == a4;
    }
    if (true) {
      long a0 = 0L;
      long a1 = 1L;
      long a2 = 2L;
      long a3 = 3L;
      long a4 = 4L;
      assert 0L == a0;
      assert 1L == a1;
      assert 2L == a2;
      assert 3L == a3;
      assert 4L == a4;
    }
    if (true) {
      double a0 = 0.0;
      double a1 = 1.0;
      double a2 = 2.0;
      double a3 = 3.0;
      double a4 = 4.0;
      assert 0.0 == a0;
      assert 1.0 == a1;
      assert 2.0 == a2;
      assert 3.0 == a3;
      assert 4.0 == a4;
    }
    if (true) {
      float a0 = 0.5f;
      float a1 = 1.0f;
      float a2 = 2.0f;
      float a3 = 3.0f;
      float a4 = 4.0f;
      assert 0.5f == a0;
      assert 1.0f == a1;
      assert 2.0f == a2;
      assert 3.0f == a3;
      assert 4.0f == a4;
    }
  }
}

